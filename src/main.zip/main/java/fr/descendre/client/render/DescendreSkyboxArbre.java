package fr.descendre.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Rendu skybox de l'arbre central lointain.
 *
 * Quand le joueur est loin de l'arbre (>200 blocs horizontalement), on affiche
 * un mesh simplifié : un cylindre 8 faces pour le tronc + un dôme pour les feuilles.
 *
 * Position monde : XZ=(0, 0), Y=-32 à Y=3000+.
 *
 * Le mesh est généré une fois et caché. Il utilise les sprites de oak_log et oak_leaves
 * pour avoir des textures cohérentes avec le monde proche.
 */
public final class DescendreSkyboxArbre {

    private static final DescendreSkyboxArbre INSTANCE = new DescendreSkyboxArbre();

    public static DescendreSkyboxArbre get() {
        return INSTANCE;
    }

    // ===== Paramètres géométriques (à ajuster si ta génération change) =====

    /** Position monde X de l'arbre. */
    private static final double TREE_X = 0.0;
    /** Position monde Z de l'arbre. */
    private static final double TREE_Z = 0.0;

    /** Rayon du tronc en blocs. */
    private static final double TRUNK_RADIUS = 100.0;
    /** Y du bas du tronc. */
    private static final double TRUNK_BOTTOM_Y = -32.0;
    /** Y du haut du tronc (= bas de la couronne). */
    private static final double TRUNK_TOP_Y = 3000.0;

    /** Rayon de la couronne de feuilles. */
    private static final double FOLIAGE_RADIUS = 550.0;
    /** Y du sommet de la couronne. */
    private static final double FOLIAGE_TOP_Y = 4000.0;

    /** Nombre de faces autour du cylindre du tronc. */
    private static final int TRUNK_SEGMENTS = 16;
    /** Nombre d'anneaux latitudinaux du dôme. */
    private static final int DOME_LATITUDES = 8;
    /** Nombre de segments longitudinaux du dôme. */
    private static final int DOME_LONGITUDES = 16;

    /** Distance horizontale minimale pour rendre le skybox (en blocs). */
    private static final double MIN_RENDER_DIST = 200.0;
    private static final double MIN_RENDER_DIST_SQ = MIN_RENDER_DIST * MIN_RENDER_DIST;

    // ===== Mesh statique généré une fois =====

    private record SkyboxQuad(
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            float x3, float y3, float z3,
            float x4, float y4, float z4,
            float nx, float ny, float nz, // normal
            boolean isFoliage              // true = leaves texture, false = oak_log
    ) {}

    private List<SkyboxQuad> quads;

    private DescendreSkyboxArbre() {}

    /** Génère le mesh à la première utilisation. */
    private void ensureBuilt() {
        if (quads != null) return;
        quads = new ArrayList<>();
        buildTrunk();
        buildDome();
    }

    private void buildTrunk() {
        double y1 = TRUNK_BOTTOM_Y;
        double y2 = TRUNK_TOP_Y;

        for (int i = 0; i < TRUNK_SEGMENTS; i++) {
            double angle1 = (Math.PI * 2 * i) / TRUNK_SEGMENTS;
            double angle2 = (Math.PI * 2 * (i + 1)) / TRUNK_SEGMENTS;

            double cos1 = Math.cos(angle1), sin1 = Math.sin(angle1);
            double cos2 = Math.cos(angle2), sin2 = Math.sin(angle2);

            double x1 = TREE_X + cos1 * TRUNK_RADIUS;
            double z1 = TREE_Z + sin1 * TRUNK_RADIUS;
            double x2 = TREE_X + cos2 * TRUNK_RADIUS;
            double z2 = TREE_Z + sin2 * TRUNK_RADIUS;

            // Normal pointant vers l'extérieur (moyenne des deux angles)
            double midAngle = (angle1 + angle2) * 0.5;
            float nx = (float) Math.cos(midAngle);
            float nz = (float) Math.sin(midAngle);

            // Quad : (x1, y1, z1) → (x2, y1, z2) → (x2, y2, z2) → (x1, y2, z1)
            // Sens horaire vue de l'extérieur (back face vers l'intérieur de l'arbre)
            quads.add(new SkyboxQuad(
                    (float) x1, (float) y1, (float) z1,
                    (float) x2, (float) y1, (float) z2,
                    (float) x2, (float) y2, (float) z2,
                    (float) x1, (float) y2, (float) z1,
                    nx, 0.0f, nz,
                    false
            ));
        }
    }

    private void buildDome() {
        double centerX = TREE_X;
        double centerZ = TREE_Z;
        double baseY = TRUNK_TOP_Y;
        double topY = FOLIAGE_TOP_Y;
        double height = topY - baseY;
        double horizontalRadius = FOLIAGE_RADIUS;

        // Demi-sphère : phi=0 au sommet, phi=PI/2 à l'équateur (base)
        for (int lat = 0; lat < DOME_LATITUDES; lat++) {
            double phi1 = (Math.PI * 0.5) * lat / DOME_LATITUDES;
            double phi2 = (Math.PI * 0.5) * (lat + 1) / DOME_LATITUDES;

            // Le ring "haut" (phi1, plus proche du sommet)
            double y1 = baseY + height * Math.cos(phi1);
            double r1 = horizontalRadius * Math.sin(phi1);
            // Le ring "bas" (phi2)
            double y2 = baseY + height * Math.cos(phi2);
            double r2 = horizontalRadius * Math.sin(phi2);

            for (int lon = 0; lon < DOME_LONGITUDES; lon++) {
                double theta1 = (Math.PI * 2 * lon) / DOME_LONGITUDES;
                double theta2 = (Math.PI * 2 * (lon + 1)) / DOME_LONGITUDES;

                double cos1 = Math.cos(theta1), sin1 = Math.sin(theta1);
                double cos2 = Math.cos(theta2), sin2 = Math.sin(theta2);

                // 4 sommets du quad
                float vx1 = (float) (centerX + cos1 * r1);
                float vz1 = (float) (centerZ + sin1 * r1);
                float vx2 = (float) (centerX + cos2 * r1);
                float vz2 = (float) (centerZ + sin2 * r1);
                float vx3 = (float) (centerX + cos2 * r2);
                float vz3 = (float) (centerZ + sin2 * r2);
                float vx4 = (float) (centerX + cos1 * r2);
                float vz4 = (float) (centerZ + sin1 * r2);

                // Normal approximative
                double midTheta = (theta1 + theta2) * 0.5;
                double midPhi = (phi1 + phi2) * 0.5;
                float nx = (float) (Math.cos(midTheta) * Math.sin(midPhi));
                float ny = (float) Math.cos(midPhi);
                float nz = (float) (Math.sin(midTheta) * Math.sin(midPhi));

                quads.add(new SkyboxQuad(
                        vx1, (float) y1, vz1,
                        vx2, (float) y1, vz2,
                        vx3, (float) y2, vz3,
                        vx4, (float) y2, vz4,
                        nx, ny, nz,
                        true
                ));
            }
        }
    }

    /**
     * Rend le skybox arbre si le joueur est suffisamment loin.
     */
    public void render(PoseStack poseStack, MultiBufferSource bufferSource, Vec3 cameraPos) {
        // Test distance : skip si on est trop proche
        double dx = TREE_X - cameraPos.x;
        double dz = TREE_Z - cameraPos.z;
        if (dx * dx + dz * dz < MIN_RENDER_DIST_SQ) return;

        ensureBuilt();

        Minecraft mc = Minecraft.getInstance();
        var modelManager = mc.getModelManager();
        TextureAtlasSprite logSprite = modelManager
                .getBlockModelShaper()
                .getParticleIcon(Blocks.OAK_LOG.defaultBlockState());
        TextureAtlasSprite leafSprite = modelManager
                .getBlockModelShaper()
                .getParticleIcon(Blocks.OAK_LEAVES.defaultBlockState());

        if (logSprite == null || leafSprite == null) return;

        // RenderType : on utilise solid pour le tronc et cutout pour les feuilles
        VertexConsumer solidConsumer = bufferSource.getBuffer(RenderType.solid());
        VertexConsumer cutoutConsumer = bufferSource.getBuffer(RenderType.cutoutMipped());

        Matrix4f pose = poseStack.last().pose();

        for (SkyboxQuad quad : quads) {
            VertexConsumer consumer = quad.isFoliage ? cutoutConsumer : solidConsumer;
            TextureAtlasSprite sprite = quad.isFoliage ? leafSprite : logSprite;

            float u0 = sprite.getU0();
            float u1 = sprite.getU1();
            float v0 = sprite.getV0();
            float v1 = sprite.getV1();

            int packedLight = (15 << 20) | (15 << 4);
            int packedOverlay = 0;

            // 4 sommets du quad avec UV qui couvrent le sprite
            consumer.addVertex(pose, quad.x1, quad.y1, quad.z1)
                    .setColor(1.0f, 1.0f, 1.0f, 1.0f)
                    .setUv(u0, v0)
                    .setOverlay(packedOverlay)
                    .setLight(packedLight)
                    .setNormal(quad.nx, quad.ny, quad.nz);
            consumer.addVertex(pose, quad.x2, quad.y2, quad.z2)
                    .setColor(1.0f, 1.0f, 1.0f, 1.0f)
                    .setUv(u1, v0)
                    .setOverlay(packedOverlay)
                    .setLight(packedLight)
                    .setNormal(quad.nx, quad.ny, quad.nz);
            consumer.addVertex(pose, quad.x3, quad.y3, quad.z3)
                    .setColor(1.0f, 1.0f, 1.0f, 1.0f)
                    .setUv(u1, v1)
                    .setOverlay(packedOverlay)
                    .setLight(packedLight)
                    .setNormal(quad.nx, quad.ny, quad.nz);
            consumer.addVertex(pose, quad.x4, quad.y4, quad.z4)
                    .setColor(1.0f, 1.0f, 1.0f, 1.0f)
                    .setUv(u0, v1)
                    .setOverlay(packedOverlay)
                    .setLight(packedLight)
                    .setNormal(quad.nx, quad.ny, quad.nz);
        }
    }
}