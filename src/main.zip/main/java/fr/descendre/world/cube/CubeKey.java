package fr.descendre.world.cube;

public class CubeKey {
}
